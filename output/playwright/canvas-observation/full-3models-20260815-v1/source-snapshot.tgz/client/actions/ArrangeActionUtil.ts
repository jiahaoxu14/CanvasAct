import { ArrangeAction } from '../../shared/schema/AgentActionSchemas'
import { Streaming } from '../../shared/types/Streaming'
import { AgentHelpers } from '../AgentHelpers'
import { AgentActionUtil, registerActionUtil } from './AgentActionUtil'
import { arrangeShapes } from './resolveSemanticActions'
import { resolveTargetSelectorForAction } from './resolveTargets'

export const ArrangeActionUtil = registerActionUtil(
	class ArrangeActionUtil extends AgentActionUtil<ArrangeAction> {
		static override type = 'arrange' as const

		override getInfo(action: Streaming<ArrangeAction>) {
			return {
				icon: 'cursor' as const,
				description: action.intent ?? '',
			}
		}

		override sanitizeAction(action: Streaming<ArrangeAction>, helpers: AgentHelpers) {
			if (!action.complete) return action

			const shapeIds = resolveTargetSelectorForAction({
				agent: this.agent,
				helpers,
				selector: action.targetSelector,
				shapeIds: action.shapeIds,
				actionType: 'arrange',
				min: 2,
			})
			if (!shapeIds) return null
			action.shapeIds = shapeIds

			return action
		}

		override applyAction(action: Streaming<ArrangeAction>, helpers: AgentHelpers) {
			if (!action.complete || !action.shapeIds) return
			arrangeShapes(this.editor, action.shapeIds, action, helpers)
		}
	}
)
